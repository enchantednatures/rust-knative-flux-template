{{/*
ksvc.loader.generate — Render all enabled resources.
Called from the consumer chart's templates/common.yaml.

Because this is a library chart, our values.yaml defaults are NOT automatically
merged. We must apply defaults explicitly before rendering.
*/}}
{{- define "ksvc.loader.generate" -}}

  {{/* ============================================================ */}}
  {{/* Apply defaults for values not provided by the consumer       */}}
  {{/* ============================================================ */}}
  {{- include "ksvc.loader.applyDefaults" . -}}

  {{/* Run validations */}}
  {{- include "ksvc.validate" . -}}

  {{/* ============================================================ */}}
  {{/* Knative Services (iterate the services map)                  */}}
  {{/* ============================================================ */}}
  {{- $isFirst := true -}}
  {{- range $key, $svc := .Values.services }}
    {{- if eq $svc.workload.type "Deployment" }}
      {{- if $isFirst -}}
        {{- $isFirst = false -}}
      {{- else }}
---
      {{- end }}
  {{- include "ksvc.class.deployment" (dict "root" $ "key" $key "svc" $svc) | nindent 0 }}
---
  {{- include "ksvc.class.deploymentService" (dict "root" $ "key" $key "svc" $svc) | nindent 0 }}
      {{- if $svc.podDisruptionBudget.enabled }}
---
  {{- include "ksvc.class.deploymentPdb" (dict "root" $ "key" $key "svc" $svc) | nindent 0 }}
      {{- end }}
    {{- else }}
    {{- if $isFirst -}}
      {{- $isFirst = false -}}
    {{- else }}
---
    {{- end }}
  {{- include "ksvc.class.knativeService" (dict "root" $ "key" $key "svc" $svc) | nindent 0 }}
    {{/* Flagger Canary (per-service opt-in) */}}
    {{- if and $svc.flagger $svc.flagger.enabled }}
---
  {{- include "ksvc.class.flaggerCanary" (dict "root" $ "key" $key "svc" $svc) | nindent 0 }}
    {{- end }}
    {{- end }}
  {{- end }}

  {{/* ============================================================ */}}
  {{/* Object Buckets (one ObjectBucketClaim per entry)             */}}
  {{/* ============================================================ */}}
  {{- if .Values.objectBuckets }}
    {{- range $key, $bucket := .Values.objectBuckets }}
---
  {{- include "ksvc.class.objectBucketClaim" (dict "root" $ "key" $key "bucket" $bucket) | nindent 0 }}
      {{- $notifications := $bucket.notifications | default dict }}
      {{- range $eventKey, $notification := $notifications }}
        {{- if $notification.enabled }}
---
  {{- include "ksvc.class.objectBucketNotification" (dict "root" $ "bucketKey" $key "eventKey" $eventKey "bucket" $bucket "notification" $notification) | nindent 0 }}
        {{- end }}
      {{- end }}
    {{- end }}
  {{- end }}

  {{/* ============================================================ */}}
  {{/* CloudNativePG PostgreSQL                                     */}}
  {{/* ============================================================ */}}
  {{- if and .Values.postgres .Values.postgres.enabled }}
---
  {{- include "ksvc.class.cnpgCluster" . | nindent 0 }}
    {{- if and .Values.postgres.pooler .Values.postgres.pooler.enabled }}
---
  {{- include "ksvc.class.cnpgPooler" . | nindent 0 }}
    {{- end }}
    {{- if and .Values.postgres.backup .Values.postgres.backup.enabled }}
---
  {{- include "ksvc.class.cnpgObjectStore" . | nindent 0 }}
---
  {{- include "ksvc.class.cnpgScheduledBackup" . | nindent 0 }}
    {{- end }}
    {{- if and .Values.postgres.monitoring .Values.postgres.monitoring.enabled }}
---
  {{- include "ksvc.class.cnpgPodMonitor" . | nindent 0 }}
---
  {{- include "ksvc.class.cnpgAlerts" . | nindent 0 }}
    {{- end }}
    {{- if and .Values.postgres.certManager .Values.postgres.certManager.enabled }}
---
  {{- include "ksvc.class.certManagerPostgres" . | nindent 0 }}
    {{- end }}
  {{- end }}

  {{- if and .Values.kafka .Values.kafka.cluster .Values.kafka.cluster.enabled }}
---
  {{- include "ksvc.class.kafkaCluster" . | nindent 0 }}
  {{- if and .Values.kafka.cluster.topics.create (or .Values.kafka.sources (include "ksvc.hasObjectBucketNotifications" .)) }}
---
  {{- include "ksvc.class.kafkaTopics" . | nindent 0 }}
  {{- end }}
  {{- if eq .Values.kafka.cluster.auth.type "scram" }}
---
  {{- include "ksvc.class.kafkaUsers" . | nindent 0 }}
  {{- end }}
  {{- end }}

  {{- if and .Values.kafka .Values.kafka.broker .Values.kafka.broker.enabled }}
  {{/* ============================================================ */}}
  {{/* Kafka Broker (eventing bus backed by Kafka)                  */}}
  {{/* ============================================================ */}}
---
  {{- include "ksvc.class.kafkaBrokerConfig" . | nindent 0 }}
---
  {{- include "ksvc.class.kafkaBroker" . | nindent 0 }}
  {{- end }}

  {{/* ============================================================ */}}
  {{/* Kafka Event Sources (iterate the kafka.sources map)          */}}
  {{/* ============================================================ */}}
  {{- if and .Values.kafka .Values.kafka.sources }}
    {{- range $key, $source := .Values.kafka.sources }}
      {{- if and $source.net $source.net.sasl $source.net.sasl.enabled }}
---
  {{- include "ksvc.class.kafkaSaslTypeSecret" (dict "root" $ "key" $key "source" $source) | nindent 0 }}
      {{- end }}
---
  {{- include "ksvc.class.kafkaSource" (dict "root" $ "key" $key "source" $source) | nindent 0 }}
      {{- if and $source.dlq $source.dlq.enabled }}
---
  {{- include "ksvc.class.kafkaDlq" (dict "root" $ "key" $key "source" $source) | nindent 0 }}
      {{- end }}
    {{- end }}
  {{- end }}

  {{- if and .Values.kafka .Values.kafka.triggers }}
  {{/* ============================================================ */}}
  {{/* Kafka Triggers (iterate the kafka.triggers map)              */}}
  {{/* ============================================================ */}}
    {{- range $key, $trigger := .Values.kafka.triggers }}
---
  {{- include "ksvc.class.kafkaTrigger" (dict "root" $ "key" $key "trigger" $trigger) | nindent 0 }}
      {{- if and $trigger.dlq $trigger.dlq.enabled }}
---
  {{- include "ksvc.class.kafkaTriggerDlq" (dict "root" $ "key" $key "trigger" $trigger) | nindent 0 }}
      {{- end }}
    {{- end }}
  {{- end }}

  {{/* ============================================================ */}}
  {{/* Ping Event Sources (iterate the pingsources map)             */}}
  {{/* ============================================================ */}}
  {{- if .Values.pingsources }}
    {{- range $key, $source := .Values.pingsources }}
---
  {{- include "ksvc.class.pingSource" (dict "root" $ "key" $key "source" $source) | nindent 0 }}
    {{- end }}
  {{- end }}

  {{/* ============================================================ */}}
  {{/* DragonflyDB Cache Cluster                                   */}}
  {{/* ============================================================ */}}
  {{- if and .Values.dragonfly .Values.dragonfly.enabled }}
---
  {{- include "ksvc.class.dragonfly" . | nindent 0 }}
    {{- if and .Values.dragonfly.tls .Values.dragonfly.tls.certManager .Values.dragonfly.tls.certManager.enabled }}
---
  {{- include "ksvc.class.certManagerDragonfly" . | nindent 0 }}
    {{- end }}
  {{- end }}

  {{/* ============================================================ */}}
  {{/* Kyverno Admission Policies (opt-in)                         */}}
  {{/* ============================================================ */}}
  {{- if and .Values.kyverno .Values.kyverno.enabled .Values.kyverno.scaling .Values.kyverno.scaling.enabled }}
---
{{- include "ksvc.class.kyvernoScaling" . | nindent 0 }}
{{- end }}

{{- end }}

{{/*
ksvc.loader.applyDefaults — Deep-merge library defaults into consumer values.
This compensates for Helm not merging library chart values.yaml automatically.
Uses mustMergeOverwrite: consumer values take precedence over defaults.
*/}}
{{- define "ksvc.loader.applyDefaults" -}}

  {{/* --- service defaults (applied to each entry in the services map) --- */}}
  {{- $svcDefaults := dict
    "image" (dict "repository" "" "tag" "latest" "pullPolicy" "IfNotPresent" "fluxImagePolicy" "" "imagePullSecrets" (list))
    "scaling" (dict "minScale" 1 "maxScale" 10 "target" 100 "containerConcurrency" 100 "timeoutSeconds" 300 "class" "" "metric" "")
    "resources" (dict "requests" (dict "cpu" "100m" "memory" "64Mi") "limits" (dict "cpu" "500m" "memory" "256Mi"))
    "port" 8080
    "probes" (dict
      "liveness" (dict "path" "/health/live" "port" 8080 "initialDelaySeconds" 3 "periodSeconds" 10 "timeoutSeconds" 2 "failureThreshold" 3)
      "readiness" (dict "path" "/health/ready" "port" 8080 "initialDelaySeconds" 5 "periodSeconds" 5 "timeoutSeconds" 3 "failureThreshold" 2)
    )
    "env" (list)
    "envFrom" (list)
    "objectBuckets" (dict)
    "securityContext" (dict
      "runAsNonRoot" true
      "runAsUser" 10001
      "readOnlyRootFilesystem" true
      "allowPrivilegeEscalation" false
      "seccompProfile" (dict "type" "RuntimeDefault")
      "capabilities" (dict "drop" (list "ALL"))
    )
    "volumeMounts" (list)
    "volumes" (list)
    "podAnnotations" (dict "prometheus.io/scrape" "true" "prometheus.io/port" "8080" "prometheus.io/path" "/metrics")
    "annotations" (dict "prometheus.io/scrape" "true" "prometheus.io/port" "8080" "prometheus.io/path" "/metrics")
    "labels" (dict)
    "workload" (dict
      "type" "Knative"
      "replicas" 1
      "strategy" (dict "maxUnavailable" 0 "maxSurge" 1)
      "terminationGracePeriodSeconds" 300
      "preStopSleepSeconds" 0
    )
    "service" (dict
      "type" "ClusterIP"
      "port" 80
      "sessionAffinity" "None"
      "sessionAffinityConfig" (dict "clientIP" (dict "timeoutSeconds" 10800))
      "externalTrafficPolicy" ""
      "annotations" (dict)
      "labels" (dict)
    )
    "podDisruptionBudget" (dict "enabled" false "minAvailable" 0 "maxUnavailable" 0)
  -}}

  {{- $loadTesterDefaults := dict "namespace" "flagger-system" "serviceName" "k6-loadtester" "scheme" "http" "port" 80 "path" "/launch-test" -}}
  {{- $flaggerTop := .Values.flagger | default dict -}}
  {{- $loadTester := mustMergeOverwrite (deepCopy $loadTesterDefaults) ($flaggerTop.loadTester | default dict) -}}
  {{- $_ := set $flaggerTop "loadTester" $loadTester -}}
  {{- $_ := set .Values "flagger" $flaggerTop -}}

  {{- $flaggerDefaults := dict
    "enabled" false
    "analysis" (dict "interval" "1m" "threshold" 5 "maxWeight" 50 "stepWeight" 10 "progressDeadlineSeconds" 120)
    "metrics" (dict "successRateThreshold" 99 "latencyP99ThresholdMs" 500)
    "loadTest" (dict "enabled" true "webhookUrl" "" "smokePath" "/health/live" "path" "/" "smokeTimeout" "1m" "timeout" "5m" "vus" 10 "duration" "1m" "p95ThresholdMs" 500 "errorRateThreshold" 0.01 "script" "")
  -}}

  {{- $rawServices := .Values.services -}}
  {{- $services := $rawServices | default dict -}}
  {{- if kindIs "map" $rawServices -}}
  {{- range $key, $svc := $services }}
    {{- $merged := mustMergeOverwrite (deepCopy $svcDefaults) $svc -}}
    {{/* Merge flagger defaults into the service's flagger config */}}
    {{- $svcFlagger := $merged.flagger | default dict -}}
    {{- $_ := set $merged "flagger" (mustMergeOverwrite (deepCopy $flaggerDefaults) $svcFlagger) -}}
    {{/* Derive the load-tester URL when the service does not override it. */}}
    {{- $lt := $merged.flagger.loadTest -}}
    {{- if not $lt.webhookUrl -}}
      {{- $scheme := $loadTester.scheme | default "http" -}}
      {{- $host := $loadTester.serviceName | default "k6-loadtester" -}}
      {{- $ns := $loadTester.namespace | default "" -}}
      {{- if $ns -}}
        {{- $host = printf "%s.%s" $host $ns -}}
      {{- end -}}
      {{- $port := int ($loadTester.port | default 80) -}}
      {{- if ne $port 80 -}}
        {{- $host = printf "%s:%d" $host $port -}}
      {{- end -}}
      {{- $path := $loadTester.path | default "/launch-test" -}}
      {{- $_ := set $lt "webhookUrl" (printf "%s://%s%s" $scheme $host $path) -}}
      {{- $_ := set $merged.flagger "loadTest" $lt -}}
    {{- end -}}
    {{/* Keep the default scrape port in sync with a custom service port. */}}
    {{- $rawAnnotations := $svc.annotations | default dict -}}
    {{- if and (kindIs "map" $merged.annotations) (not (and (kindIs "map" $rawAnnotations) (hasKey $rawAnnotations "prometheus.io/port"))) -}}
      {{- $_ := set $merged.annotations "prometheus.io/port" (toString $merged.port) -}}
    {{- end -}}
    {{- $rawPodAnnotations := $svc.podAnnotations | default dict -}}
    {{- if and (kindIs "map" $merged.podAnnotations) (not (and (kindIs "map" $rawPodAnnotations) (hasKey $rawPodAnnotations "prometheus.io/port"))) -}}
      {{- $_ := set $merged.podAnnotations "prometheus.io/port" (toString $merged.port) -}}
    {{- end -}}
    {{/* Expose referenced object buckets to this service. */}}
    {{- $svcBuckets := $merged.objectBuckets | default dict -}}
    {{- if kindIs "map" $svcBuckets -}}
      {{- range $bucketKey, $binding := $svcBuckets }}
        {{- $bindingDefaults := dict "mode" "envFrom" "configMapName" "" "secretName" ""
          "envNames" (dict
            "bucketName" "BUCKET_NAME"
            "bucketHost" "BUCKET_HOST"
            "bucketPort" "BUCKET_PORT"
            "accessKeyId" "AWS_ACCESS_KEY_ID"
            "secretAccessKey" "AWS_SECRET_ACCESS_KEY"
          )
        -}}
        {{- $_ := set $svcBuckets $bucketKey (mustMergeOverwrite (deepCopy $bindingDefaults) ($binding | default dict)) -}}
      {{- end -}}
      {{- $_ := set $merged "objectBuckets" $svcBuckets -}}
      {{- range $bucketKey, $binding := $svcBuckets }}
        {{- $claimName := include "ksvc.objectBucketName" (dict "root" $ "key" $bucketKey) -}}
        {{- $configMapName := $binding.configMapName | default $claimName -}}
        {{- $secretName := $binding.secretName | default $claimName -}}
        {{- if eq ($binding.mode | default "envFrom") "envFrom" }}
          {{- $envFrom := $merged.envFrom | default list -}}
          {{- $hasSecretRef := false -}}
          {{- $hasConfigMapRef := false -}}
          {{- range $source := $envFrom }}
            {{- if and (kindIs "map" $source) (hasKey $source "secretRef") -}}
              {{- $ref := index $source "secretRef" -}}
              {{- if and (kindIs "map" $ref) (eq (toString (index $ref "name" | default "")) $secretName) -}}
                {{- $hasSecretRef = true -}}
              {{- end -}}
            {{- end -}}
            {{- if and (kindIs "map" $source) (hasKey $source "configMapRef") -}}
              {{- $ref := index $source "configMapRef" -}}
              {{- if and (kindIs "map" $ref) (eq (toString (index $ref "name" | default "")) $configMapName) -}}
                {{- $hasConfigMapRef = true -}}
              {{- end -}}
            {{- end -}}
          {{- end -}}
          {{- if not $hasSecretRef -}}
            {{- $envFrom = append $envFrom (dict "secretRef" (dict "name" $secretName)) -}}
          {{- end -}}
          {{- if not $hasConfigMapRef -}}
            {{- $envFrom = append $envFrom (dict "configMapRef" (dict "name" $configMapName)) -}}
          {{- end -}}
          {{- $_ := set $merged "envFrom" $envFrom -}}
        {{- else if eq ($binding.mode | default "envFrom") "env" }}
          {{- $env := $merged.env | default list -}}
          {{- $existingEnv := dict -}}
          {{- range $entry := $env }}
            {{- if and (kindIs "map" $entry) (hasKey $entry "name") -}}
              {{- $_ := set $existingEnv (toString (index $entry "name")) true -}}
            {{- end -}}
          {{- end -}}
          {{- $envNames := mustMergeOverwrite (deepCopy (dict "bucketName" "BUCKET_NAME" "bucketHost" "BUCKET_HOST" "bucketPort" "BUCKET_PORT" "accessKeyId" "AWS_ACCESS_KEY_ID" "secretAccessKey" "AWS_SECRET_ACCESS_KEY")) ($binding.envNames | default dict) -}}
          {{- $configKeys := dict "bucketName" "BUCKET_NAME" "bucketHost" "BUCKET_HOST" "bucketPort" "BUCKET_PORT" -}}
          {{- range $field, $sourceKey := $configKeys }}
            {{- $target := toString (index $envNames $field | default "") -}}
            {{- if and $target (not (hasKey $existingEnv $target)) }}
              {{- $env = append $env (dict "name" $target "valueFrom" (dict "configMapKeyRef" (dict "name" $configMapName "key" $sourceKey))) -}}
              {{- $_ := set $existingEnv $target true -}}
            {{- end -}}
          {{- end -}}
          {{- $secretKeys := dict "accessKeyId" "AWS_ACCESS_KEY_ID" "secretAccessKey" "AWS_SECRET_ACCESS_KEY" -}}
          {{- range $field, $sourceKey := $secretKeys }}
            {{- $target := toString (index $envNames $field | default "") -}}
            {{- if and $target (not (hasKey $existingEnv $target)) }}
              {{- $env = append $env (dict "name" $target "valueFrom" (dict "secretKeyRef" (dict "name" $secretName "key" $sourceKey))) -}}
              {{- $_ := set $existingEnv $target true -}}
            {{- end -}}
          {{- end -}}
          {{- $_ := set $merged "env" $env -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
    {{- $_ := set $services $key $merged -}}
  {{- end -}}
  {{- $_ := set .Values "services" $services -}}
  {{- end -}}

  {{/* --- kafka source, cluster, broker, and trigger defaults --- */}}
  {{- $kafkaBootstrapDefaults := list "kafka.kafka.svc.cluster.local:9092" -}}
  {{- $kafkaValues := .Values.kafka | default dict -}}
  {{- $defaultBootstrap := $kafkaValues.bootstrapServers | default $kafkaBootstrapDefaults -}}
  {{- $kafkaSourceDefaults := dict
    "topic" "events"
    "consumerGroup" ""
    "bootstrapServers" $defaultBootstrap
    "consumers" 3
    "initialOffset" "latest"
    "sink" ""
    "delivery" (dict "retry" 5 "backoffPolicy" "exponential" "backoffDelay" "PT1S")
    "dlq" (dict "enabled" true
      "image" (dict "repository" "gcr.io/knative-releases/knative.dev/eventing/cmd/event_display" "tag" "latest")
      "port" 8080
      "env" (list
        (dict "name" "POD_NAME" "valueFrom" (dict "fieldRef" (dict "fieldPath" "metadata.name")))
        (dict "name" "POD_NAMESPACE" "valueFrom" (dict "fieldRef" (dict "fieldPath" "metadata.namespace")))
      )
      "scaling" (dict "minScale" 0 "maxScale" 2)
      "resources" (dict "requests" (dict "cpu" "50m" "memory" "32Mi") "limits" (dict "cpu" "200m" "memory" "128Mi"))
    )
    "net" (dict
      "tls" (dict "enabled" false "caCertSecret" "" "caCertKey" "ca.crt" "certSecret" "" "certKey" "tls.crt" "keySecret" "" "keyKey" "tls.key")
      "sasl" (dict "enabled" false "mechanism" "SCRAM-SHA-512" "userSecret" "" "userKey" "user" "passwordSecret" "" "passwordKey" "password")
    )
  -}}

  {{- $clusterDefaults := dict
    "enabled" false
    "provider" "strimzi"
    "name" ""
    "replicas" 3
    "listeners" (dict "plainPort" 9092 "tlsPort" 9093)
    "storage" (dict "size" "20Gi" "storageClassName" "")
    "resources" (dict "requests" (dict "cpu" "500m" "memory" "1Gi") "limits" (dict "cpu" "2" "memory" "4Gi"))
    "tls" (dict "enabled" false)
    "auth" (dict "type" "none" "username" "")
    "topics" (dict "create" true "partitions" 3)
    "strimzi" (dict "version" "" "metadataVersion" "" "extraSpec" (dict) "nodePoolExtraSpec" (dict))
    "redpanda" (dict "extraClusterSpec" (dict) "sasl" (dict "secretRef" ""))
  -}}

  {{- $brokerDefaults := dict
    "enabled" false
    "externalTopic" ""
    "annotations" (dict)
    "config" (dict
      "topicPartitions" 10
      "topicReplicationFactor" 3
      "authSecretName" ""
      "extra" (dict)
    )
    "delivery" (dict
      "retry" 5
      "backoffPolicy" "exponential"
      "backoffDelay" "PT1S"
      "deadLetterSink" (dict "enabled" false "uri" "" "ref" (dict "apiVersion" "serving.knative.dev/v1" "kind" "Service" "name" ""))
    )
  -}}

  {{- $triggerDefaults := dict
    "subscriber" ""
    "subscriberUri" ""
    "filter" (dict)
    "filters" (list)
    "annotations" (dict)
    "delivery" (dict "retry" 5 "backoffPolicy" "exponential" "backoffDelay" "PT1S")
    "dlq" (dict "enabled" false
      "image" (dict "repository" "gcr.io/knative-releases/knative.dev/eventing/cmd/event_display" "tag" "latest")
      "port" 8080
      "env" (list
        (dict "name" "POD_NAME" "valueFrom" (dict "fieldRef" (dict "fieldPath" "metadata.name")))
        (dict "name" "POD_NAMESPACE" "valueFrom" (dict "fieldRef" (dict "fieldPath" "metadata.namespace")))
      )
      "scaling" (dict "minScale" 0 "maxScale" 2)
      "resources" (dict "requests" (dict "cpu" "50m" "memory" "32Mi") "limits" (dict "cpu" "200m" "memory" "128Mi"))
    )
  -}}

  {{- $kafka := $kafkaValues -}}
  {{- $_ := set $kafka "bootstrapServers" $defaultBootstrap -}}
  {{- if or (not (hasKey $kafka "sources")) (not $kafka.sources) -}}
    {{- $_ := set $kafka "sources" dict -}}
  {{- end -}}

  {{- $rawSourceBootstrap := dict -}}
  {{- range $key, $source := $kafka.sources -}}
    {{- if and (hasKey $source "bootstrapServers") $source.bootstrapServers -}}
      {{- $_ := set $rawSourceBootstrap $key $source.bootstrapServers -}}
    {{- end -}}
  {{- end -}}

  {{- $rawBrokerBootstrap := list -}}
  {{- if and (hasKey $kafka "broker") $kafka.broker -}}
    {{- $rawBrokerConfig := $kafka.broker.config | default dict -}}
    {{- if and (hasKey $rawBrokerConfig "bootstrapServers") $rawBrokerConfig.bootstrapServers -}}
      {{- $rawBrokerBootstrap = $rawBrokerConfig.bootstrapServers -}}
    {{- end -}}
  {{- end -}}

  {{- $cluster := $kafka.cluster | default dict -}}
  {{- if not (kindIs "map" $cluster) -}}
    {{- $cluster = dict -}}
  {{- end -}}
  {{- $_ := set $kafka "cluster" (mustMergeOverwrite (deepCopy $clusterDefaults) $cluster) -}}
  {{- $cluster = $kafka.cluster -}}

  {{- range $key, $source := $kafka.sources }}
    {{- $merged := mustMergeOverwrite (deepCopy $kafkaSourceDefaults) $source -}}
    {{- if $cluster.enabled -}}
      {{- $derivedBootstrap := list (include "ksvc.kafkaBootstrapServers" $) -}}
      {{- if hasKey $rawSourceBootstrap $key -}}
        {{- if ne (toYaml (index $rawSourceBootstrap $key)) (toYaml $derivedBootstrap) -}}
          {{- fail (printf "kafka.sources.%s.bootstrapServers must not be set when kafka.cluster.enabled=true (derived: %s)" $key (join "," $derivedBootstrap)) -}}
        {{- end -}}
      {{- else -}}
        {{- $_ := set $merged "bootstrapServers" $derivedBootstrap -}}
      {{- end -}}
      {{- $net := $merged.net | default dict -}}
      {{- if not (kindIs "map" $net) -}}
        {{- $net = dict -}}
      {{- end -}}
      {{- $tls := $net.tls | default dict -}}
      {{- if not (kindIs "map" $tls) -}}
        {{- $tls = dict -}}
      {{- end -}}
      {{- $sasl := $net.sasl | default dict -}}
      {{- if not (kindIs "map" $sasl) -}}
        {{- $sasl = dict -}}
      {{- end -}}
      {{- if and $tls.enabled (not $tls.caCertSecret) -}}
        {{- if eq $cluster.provider "redpanda" -}}
          {{- $_ := set $tls "caCertSecret" (printf "%s-default-cert" (include "ksvc.kafkaClusterName" $)) -}}
        {{- else -}}
          {{- $_ := set $tls "caCertSecret" (printf "%s-cluster-ca-cert" (include "ksvc.kafkaClusterName" $)) -}}
        {{- end -}}
      {{- end -}}
      {{- if and $sasl.enabled (eq $cluster.auth.type "scram") (not $sasl.userSecret) -}}
        {{- $_ := set $sasl "userSecret" (include "ksvc.kafkaSourceSaslTypeSecretName" (dict "root" $ "key" $key)) -}}
      {{- end -}}
      {{- if and $sasl.enabled (eq $cluster.auth.type "scram") (not $sasl.passwordSecret) -}}
        {{- $_ := set $sasl "passwordSecret" (include "ksvc.kafkaUserSecretName" $) -}}
      {{- end -}}
      {{- $_ := set $net "tls" $tls -}}
      {{- $_ := set $net "sasl" $sasl -}}
      {{- $_ := set $merged "net" $net -}}
    {{- end -}}
    {{- $_ := set $kafka.sources $key $merged -}}
  {{- end }}

  {{- $broker := $kafka.broker | default dict -}}
  {{- $_ := set $kafka "broker" (mustMergeOverwrite (deepCopy $brokerDefaults) $broker) -}}
  {{- $broker = $kafka.broker -}}
  {{- $brokerConfig := $broker.config | default dict -}}
  {{- if not (kindIs "map" $brokerConfig) -}}
    {{- $brokerConfig = deepCopy $brokerDefaults.config -}}
  {{- end -}}
  {{- if not (hasKey $brokerConfig "bootstrapServers") -}}
    {{- $_ := set $brokerConfig "bootstrapServers" $defaultBootstrap -}}
  {{- end -}}
  {{- if $cluster.enabled -}}
    {{- $derivedBootstrap := list (include "ksvc.kafkaBootstrapServers" $) -}}
    {{- if $rawBrokerBootstrap -}}
      {{- if ne (toYaml $rawBrokerBootstrap) (toYaml $derivedBootstrap) -}}
        {{- fail (printf "kafka.broker.config.bootstrapServers must not be set when kafka.cluster.enabled=true (derived: %s)" (join "," $derivedBootstrap)) -}}
      {{- end -}}
    {{- else -}}
      {{- $_ := set $brokerConfig "bootstrapServers" $derivedBootstrap -}}
    {{- end -}}
    {{- $_ := set $brokerConfig "topicReplicationFactor" (int (include "ksvc.kafkaTopicReplicationFactor" $)) -}}
  {{- end -}}
  {{- $_ := set $broker "config" $brokerConfig -}}
  {{- $_ := set $kafka "broker" $broker -}}

  {{- if or (not (hasKey $kafka "triggers")) (not $kafka.triggers) -}}
    {{- $_ := set $kafka "triggers" dict -}}
  {{- end -}}
  {{- range $key, $trigger := $kafka.triggers }}
    {{- $merged := mustMergeOverwrite (deepCopy $triggerDefaults) $trigger -}}
    {{- $_ := set $kafka.triggers $key $merged -}}
  {{- end }}
  {{- $_ := set .Values "kafka" $kafka -}}

  {{/* --- pingsource defaults (applied to each entry in the pingsources map) --- */}}
  {{- $pingSourceDefaults := dict
    "schedule" "0 * * * *"
    "timezone" "UTC"
    "data" ""
    "contentType" "application/json"
    "sink" ""
    "ceOverrides" (dict "extensions" (dict))
  -}}

  {{- $pingSources := .Values.pingsources | default dict -}}
  {{- range $key, $source := $pingSources }}
    {{- $merged := mustMergeOverwrite (deepCopy $pingSourceDefaults) $source -}}
    {{- $_ := set $pingSources $key $merged -}}
  {{- end }}
  {{- $_ := set .Values "pingsources" $pingSources -}}

  {{/* --- object bucket defaults (applied to each entry in the objectBuckets map) --- */}}
  {{- $notificationDefaults := dict "enabled" false "topicName" "" "persistent" false "opaqueData" "" "ackLevel" "broker" "filter" (dict) -}}
  {{- $bucketDefaults := dict "bucketName" "" "endpointURL" "" "region" "" "objectStore" (dict "name" "" "namespace" "") "notifications" (dict) -}}
  {{- $buckets := .Values.objectBuckets | default dict -}}
  {{- range $key, $bucket := $buckets }}
    {{- $merged := mustMergeOverwrite (deepCopy $bucketDefaults) $bucket -}}
    {{- $_ := set $merged "bucketName" (default (include "ksvc.objectBucketName" (dict "root" $ "key" $key)) $merged.bucketName) -}}
    {{- $notifications := $merged.notifications | default dict -}}
    {{- if kindIs "map" $notifications -}}
      {{- range $eventKey, $notification := $notifications }}
        {{- $_ := set $notifications $eventKey (mustMergeOverwrite (deepCopy $notificationDefaults) ($notification | default dict)) -}}
      {{- end -}}
      {{- $_ := set $merged "notifications" $notifications -}}
    {{- end -}}
    {{- $_ := set $buckets $key $merged -}}
  {{- end -}}
  {{- $_ := set .Values "objectBuckets" $buckets -}}

  {{/* --- postgres defaults --- */}}
  {{/* Capture RAW consumer objectStore values before the merge so bucketRef
       derivation can tell "consumer set it" apart from "we defaulted it".
       NOTE: sprig `dig` type-asserts its dict to map[string]interface{} and
       rejects chartutil.Values, so walk the nested maps explicitly instead. */}}
  {{- $pgRaw := .Values.postgres | default dict -}}
  {{- $pgBackupRaw := $pgRaw.backup | default dict -}}
  {{- $pgStoreRaw := $pgBackupRaw.objectStore | default dict -}}
  {{- $pgCredsRaw := $pgStoreRaw.s3Credentials | default dict -}}
  {{- $rawPgBucketRef := $pgStoreRaw.bucketRef | default "" -}}
  {{- $rawPgDestPath := $pgStoreRaw.destinationPath | default "" -}}
  {{- $rawPgEndpoint := $pgStoreRaw.endpointURL | default "" -}}
  {{- $rawPgCredSecret := $pgCredsRaw.secretName | default "" -}}
  {{- $rawPgCredAccess := $pgCredsRaw.accessKeyIdKey | default "" -}}
  {{- $rawPgCredSecretKey := $pgCredsRaw.secretAccessKeyKey | default "" -}}
  {{- $pgCredsProvided := or $rawPgCredSecret $rawPgCredAccess $rawPgCredSecretKey -}}
  {{- $pgDefaults := dict
    "enabled" false
    "version" "16"
    "instances" 3
    "imageCatalog" (dict "name" "postgresql")
    "parameters" (dict "ssl" "on" "ssl_min_protocol_version" "TLSv1.3" "ssl_max_protocol_version" "TLSv1.3" "shared_buffers" "2Gi" "max_connections" "300" "synchronous_commit" "remote_apply" "synchronous_standby_names" "ANY 1 (*)" "archive_timeout" "5min" "wal_compression" "on")
    "sharedPreloadLibraries" (list "pg_stat_statements")
    "postInitSQL" (list "CREATE EXTENSION IF NOT EXISTS pg_stat_statements;")
    "resources" (dict "requests" (dict "cpu" "1" "memory" "2Gi") "limits" (dict "cpu" "2" "memory" "4Gi"))
    "storage" (dict "size" "200Gi" "storageClassName" "standard")
    "pooler" (dict "enabled" true "instances" 3 "type" "rw" "poolMode" "transaction"
      "parameters" (dict "max_client_conn" "300" "default_pool_size" "25" "reserve_pool_size" "5" "reserve_pool_timeout" "5" "max_db_connections" "100" "server_lifetime" "3600" "server_idle_timeout" "600" "log_connections" "1" "log_disconnections" "1" "log_pooler_errors" "1")
      "resources" (dict "requests" (dict "cpu" "100m" "memory" "128Mi") "limits" (dict "cpu" "500m" "memory" "256Mi"))
    )
    "backup" (dict "enabled" true "schedule" "0 2 * * *" "target" "prefer-standby" "retentionPolicy" "30d"
      "objectStore" (dict "bucketRef" "" "destinationPath" "" "endpointURL" ""
        "s3Credentials" (dict "secretName" "postgres-backup-storage" "accessKeyIdKey" "ACCESS_KEY_ID" "secretAccessKeyKey" "ACCESS_SECRET_KEY")
        "data" (dict "compression" "gzip" "jobs" 2)
        "wal" (dict "compression" "gzip" "maxParallel" 4)
      )
    )
    "monitoring" (dict
      "enabled" true
      "podMonitor" (dict
        "labels" (dict "release" "prometheus")
        "interval" "30s"
        "scrapeTimeout" "10s"
        "path" "/metrics"
        "scheme" "http"
      )
      "prometheusRule" (dict
        "labels" (dict "prometheus" "kube-prometheus")
        "interval" "30s"
      )
      "alerts" (dict "replicationLagWarning" 10 "replicationLagCritical" 60 "highConnectionCount" 50)
    )
    "certManager" (dict "enabled" false "issuerRef" (dict "name" "" "kind" "" "group" ""))
  -}}
  {{- $pg := .Values.postgres | default dict -}}
  {{- $_ := set .Values "postgres" (mustMergeOverwrite $pgDefaults $pg) -}}

  {{/* --- postgres bucketRef wiring (objectBuckets entries are defaulted above) --- */}}
  {{- if and $rawPgBucketRef (hasKey (.Values.objectBuckets | default dict) $rawPgBucketRef) -}}
    {{- $entry := index .Values.objectBuckets $rawPgBucketRef -}}
    {{- $claimName := include "ksvc.objectBucketName" (dict "root" $ "key" $rawPgBucketRef) -}}
    {{- $store := .Values.postgres.backup.objectStore -}}
    {{- if not $rawPgDestPath -}}
      {{- $_ := set $store "destinationPath" (printf "s3://%s/" $entry.bucketName) -}}
    {{- end -}}
    {{- if not $rawPgEndpoint -}}
      {{- $_ := set $store "endpointURL" $entry.endpointURL -}}
    {{- end -}}
    {{- if not $pgCredsProvided -}}
      {{- $_ := set $store.s3Credentials "secretName" $claimName -}}
      {{- $_ := set $store.s3Credentials "accessKeyIdKey" "AWS_ACCESS_KEY_ID" -}}
      {{- $_ := set $store.s3Credentials "secretAccessKeyKey" "AWS_SECRET_ACCESS_KEY" -}}
    {{- end -}}
  {{- end -}}

  {{/* --- dragonfly defaults --- */}}
  {{- $dfDefaults := dict
    "enabled" false
    "replicas" 3
    "image" "docker.dragonflydb.io/dragonflydb/dragonfly"
    "imageTag" "v1.21.2"
    "args" (list)
    "env" (list)
    "resources" (dict "requests" (dict "cpu" "500m" "memory" "512Mi") "limits" (dict "cpu" "1" "memory" "1Gi"))
    "authentication" (dict "passwordFromSecret" (dict "name" "" "key" "password") "clientCaCertSecret" (dict "name" "" "key" "ca.crt"))
    "tls" (dict "secretName" "" "certManager" (dict "enabled" false "issuerRef" (dict "name" "" "kind" "" "group" "") "duration" "2160h" "renewBefore" "360h"))
    "snapshot" (dict "enabled" false "cron" "0 */6 * * *" "enableOnMasterOnly" true "bucketRef" ""
      "storage" (dict "size" "10Gi" "storageClassName" "")
    )
    "serviceSpec" (dict "type" "ClusterIP" "name" "" "nodePort" 0 "annotations" (dict) "labels" (dict))
    "pdb" (dict "minAvailable" 2 "maxUnavailable" 0)
    "affinity" (dict)
    "tolerations" (list)
    "topologySpreadConstraints" (list)
    "nodeSelector" (dict)
    "podSecurityContext" (dict)
    "containerSecurityContext" (dict)
    "serviceAccountName" ""
    "priorityClassName" ""
  -}}
  {{- $df := .Values.dragonfly | default dict -}}
  {{- $_ := set .Values "dragonfly" (mustMergeOverwrite $dfDefaults $df) -}}

  {{/* --- kyverno defaults --- */}}
  {{- $kyvernoDefaults := dict
    "enabled" false
    "scaling" (dict "enabled" false "apiVersion" "policies.kyverno.io/v1beta1" "validationActions" (list "Deny"))
  -}}
  {{- $kyverno := .Values.kyverno | default dict -}}
  {{- $_ := set .Values "kyverno" (mustMergeOverwrite $kyvernoDefaults $kyverno) -}}

  {{/* --- global defaults --- */}}
  {{- $globalDefaults := dict
    "nameOverride" ""
    "fullnameOverride" ""
    "clusterDomain" "cluster.local"
    "labels" (dict)
    "annotations" (dict)
    "certManager" (dict "issuerRef" (dict "name" "" "kind" "ClusterIssuer" "group" "cert-manager.io"))
  -}}
  {{- $global := .Values.global | default dict -}}
  {{- $_ := set .Values "global" (mustMergeOverwrite $globalDefaults $global) -}}

{{- end }}
