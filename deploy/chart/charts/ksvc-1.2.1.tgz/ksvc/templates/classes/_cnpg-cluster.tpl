{{- define "ksvc.class.cnpgCluster" -}}
{{- $pg := .Values.postgres -}}
{{- $pgName := include "ksvc.postgresName" . -}}
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata:
  name: {{ $pgName }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "ksvc.labels" . | nindent 4 }}
    app.kubernetes.io/component: database
  {{- $globalAnnotations := include "ksvc.annotations" . -}}
  {{- with $globalAnnotations }}
  annotations:
    {{- . | nindent 4 }}
  {{- end }}
spec:
  instances: {{ $pg.instances }}
  imageCatalogRef:
    apiGroup: postgresql.cnpg.io
    kind: ClusterImageCatalog
    name: {{ $pg.imageCatalog.name | quote }}
    major: {{ $pg.version | int }}
  postgresql:
    parameters:
      {{- toYaml $pg.parameters | nindent 6 }}
    shared_preload_libraries:
      {{- toYaml $pg.sharedPreloadLibraries | nindent 6 }}
  resources:
    {{- toYaml $pg.resources | nindent 4 }}
  storage:
    size: {{ $pg.storage.size | quote }}
    storageClass: {{ $pg.storage.storageClassName | quote }}
  {{- if $pg.backup.enabled }}
  plugins:
    - name: barman-cloud.cloudnative-pg.io
      isWALArchiver: true
      parameters:
        barmanObjectName: {{ include "ksvc.postgresBackupStoreName" . }}
  {{- end }}
  bootstrap:
    initdb:
      postInitApplicationSQL:
        {{- toYaml $pg.postInitSQL | nindent 8 }}
  {{- if and $pg.certManager $pg.certManager.enabled }}
  certificates:
    serverTLSSecret: {{ include "ksvc.postgresServerTLSSecret" . }}
    serverCASecret: {{ include "ksvc.postgresServerTLSSecret" . }}
    clientCASecret: {{ include "ksvc.postgresClientTLSSecret" . }}
    replicationTLSSecret: {{ include "ksvc.postgresClientTLSSecret" . }}
  {{- end }}
{{- end }}
