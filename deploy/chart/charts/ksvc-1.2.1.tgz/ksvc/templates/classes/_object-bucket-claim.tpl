{{/*
ksvc.class.objectBucketClaim — Render an ObjectBucketClaim for one objectBuckets entry.
Expects context: dict with "root" (top-level context), "key" (bucket map key),
and "bucket" (the merged bucket entry config dict).
The referenced StorageClass provisions the bucket on the object store (Rook/Ceph);
storageClassName is required and only referenced, never rendered.
*/}}
{{- define "ksvc.class.objectBucketClaim" -}}
apiVersion: objectbucket.io/v1alpha1
kind: ObjectBucketClaim
metadata:
  name: {{ include "ksvc.objectBucketName" (dict "root" .root "key" .key) }}
  namespace: {{ .root.Release.Namespace }}
  labels:
    {{- include "ksvc.labels" .root | nindent 4 }}
    app.kubernetes.io/component: object-bucket
    {{- $root := .root }}
    {{- $bucketKey := .key }}
    {{- $notifications := .bucket.notifications | default dict }}
    {{- range $eventKey, $notification := $notifications }}
    {{- if $notification.enabled }}
    {{- $notificationName := include "ksvc.objectBucketNotificationName" (dict "root" $root "bucketKey" $bucketKey "eventKey" $eventKey) }}
    bucket-notification-{{ $notificationName }}: {{ $notificationName | quote }}
    {{- end }}
    {{- end }}
  {{- $globalAnnotations := include "ksvc.annotations" .root -}}
  {{- with $globalAnnotations }}
  annotations:
    {{- . | nindent 4 }}
  {{- end }}
spec:
  storageClassName: {{ .bucket.storageClassName | quote }}
  bucketName: {{ .bucket.bucketName | quote }}
{{- end }}
